﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Mail;
using System.Text;

namespace NotificationEmailer
{
    public class SendEmailer
    {
        public static void SendEmailerToAdmin(ref int emailStatus,string Useremail)
        {
            try
            {
                string textBody = "<table border=" + 1 + " cellpadding=" + 0 + " cellspacing=" + 0 + " width = " + 400 + "><tr><td><b>Project</b></td> <td> <b> Email </b> </td><td> <b> Status </b> </td></tr><tr><td><b>Api Project</b></td> <td> <b>{0}s</b> </td><td><a href='http://localhost:49334/api/Login/ActivateUser?email={1}'>Activate User</a></td></tr>";
                textBody += "</table>";
                string body=String.Format(textBody, Useremail, Useremail);
                MailMessage msg = new MailMessage();
                msg.From = new MailAddress("FromMailAddress");
                msg.To.Add(new MailAddress("ToMailAddress"));
                msg.Subject = "API Project User Activation Email";
                msg.Body = body;
                msg.IsBodyHtml = true;
                SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
                client.Credentials = new System.Net.NetworkCredential()
                {
                    UserName = "xxxx",
                    Password = "xxx"

                };
                client.EnableSsl = true;
                client.Send(msg);
                emailStatus = 1;
            }
            catch (Exception ex)
            {
                emailStatus = 0;
            }

        }
    }
}
