﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using APIServices.IServices;


namespace APIProject.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private ILogin _loign;
        public LoginController(ILogin login)
        {
            this._loign = login;
        }

        [HttpGet]
        public IActionResult RegisterUser(string Username, string pwd)
        {
            HttpResponseMessage _result;
            try
            {
                int response = this._loign.RegisterUser(Username, pwd);
                _result = new HttpResponseMessage() { StatusCode = HttpStatusCode.OK, Content = new StringContent(JsonConvert.SerializeObject(response)) };
            }
            catch (Exception EX)
            {
                _result = new HttpResponseMessage() { StatusCode = HttpStatusCode.BadRequest, Content = new StringContent(JsonConvert.SerializeObject("please Contact Adminstrator")) };
            }
            return Ok(_result.Content.ReadAsStringAsync().Result);
        }
    }
}
