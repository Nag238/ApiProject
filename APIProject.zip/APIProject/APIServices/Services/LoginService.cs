﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using APIServices.IServices;
using Microsoft.Extensions.Configuration;

namespace APIServices.Services
{
    public class LoginService : ILogin
    {
        SqlConnection _conn;
        SqlCommand _cmd;

        private IConfiguration _configuration;

        public LoginService(IConfiguration _config)
        {
            this._configuration = _config;
        }

        public int RegisterUser(string Username, string Pwd)
        {
            using (_conn = new SqlConnection("connectionstring"))
            {
                _cmd = new SqlCommand("sp_name", _conn);
                _cmd.CommandType = System.Data.CommandType.StoredProcedure;
                _cmd.Parameters.AddWithValue("@Username", Username);
                _cmd.Parameters.AddWithValue("@Pwd", Pwd);
                int result = _cmd.ExecuteNonQuery();
                if (result == 0)
                    return 0;
                else
                    return 1;
            }
        }
    }
}
