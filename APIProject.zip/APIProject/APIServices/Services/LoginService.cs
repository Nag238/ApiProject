﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using APIServices.IServices;
using Microsoft.Extensions.Configuration;
using NotificationEmailer;

namespace APIServices.Services
{
    public class LoginService : ILogin
    {
        SqlConnection _conn;
        SqlCommand _cmd;

        private IConfiguration _configuration;

        public LoginService(IConfiguration _config)
        {
            this._configuration = _config;
        }

        public string ActivateUser(string email)
        {
            using (_conn = new SqlConnection(this._configuration["ConnectionStrings"]))
            {
                _cmd = new SqlCommand("sp_activateuser", _conn);
                _cmd.CommandType = System.Data.CommandType.StoredProcedure;
                _cmd.Parameters.AddWithValue("@email", email);
                _conn.Open();
               int status = _cmd.ExecuteNonQuery();
                _conn.Close();
                if (status >= 1)
                {
                    return email + " has benn Activated";
                }
                else
                    return email + " activation failed";
            }
        }

        public string RegisterUser(string Username, string Pwd)
        {
            int emailStatus = 0;
            using (_conn = new SqlConnection(this._configuration["ConnectionStrings"]))
            {
                _cmd = new SqlCommand("sp_registerUser", _conn);
                _cmd.CommandType = System.Data.CommandType.StoredProcedure;
                _cmd.Parameters.AddWithValue("@Email", Username);
                _cmd.Parameters.AddWithValue("@Password", Pwd);
                _conn.Open();
                int result = _cmd.ExecuteNonQuery();
                _conn.Close();
                if (result == 0)
                    return "User Registration Failed";
                else
                {
                    SendEmailer.SendEmailerToAdmin(ref emailStatus,Username);
                    if (emailStatus == 0)
                    {
                       return  "Unable to Send email to the User";
                    }
                    else
                    {
                        return "Succusfully Sent Email To the User";
                    }
                }
            }
        }
    }
}
