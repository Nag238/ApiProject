﻿using System;
using System.Collections.Generic;
using System.Text;

namespace APIServices.IServices
{
    public interface ILogin
    {
        int RegisterUser(string Username, string Pwd);
    }
}
