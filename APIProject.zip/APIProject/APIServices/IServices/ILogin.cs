﻿using System;
using System.Collections.Generic;
using System.Text;

namespace APIServices.IServices
{
    public interface ILogin
    {
        string RegisterUser(string Username, string Pwd);
        string ActivateUser(string email);
    }
}
